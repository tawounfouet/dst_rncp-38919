from pathlib import Path
import sys

project = Path(__file__).resolve().parents[1] / "exam" / "correction" / "reference_project"
required = [
    "app/main.py",
    "app/config.py",
    "app/schemas.py",
    "models/model.joblib",
    "tests/test_api.py",
    ".gitlab-ci.yml",
    "Dockerfile",
    "docker-compose.yml",
    "config/prometheus.yml",
    "grafana/provisioning/datasources/prometheus.yml",
    "k8s/namespace.yml",
    "k8s/configmap.yml",
    "k8s/pv.yml",
    "k8s/pvc.yml",
    "k8s/deployment.yml",
    "k8s/service.yml",
]
missing = [item for item in required if not (project / item).exists()]
if missing:
    print("Missing:")
    print("\n".join(missing))
    sys.exit(1)
print(f"Reference project structure: OK ({len(required)} required files)")
