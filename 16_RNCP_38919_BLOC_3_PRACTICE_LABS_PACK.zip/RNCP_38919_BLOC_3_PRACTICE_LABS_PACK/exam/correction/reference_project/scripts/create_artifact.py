from pathlib import Path
import joblib
from app.demo_model import DemoRiskModel

Path("models").mkdir(parents=True, exist_ok=True)
joblib.dump(DemoRiskModel(), "models/model.joblib")
print("models/model.joblib created")
